<?php

namespace App\Controller;

use App\Entity\Etudiant;
use App\Form\EtudiantFormType;
use App\Repository\EtudiantRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request; 
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class EtudiantController extends AbstractController
{
    #[Route('/', name: 'home')]
    public function home(): Response
    {
        return $this->render('base.html.twig',);
    }
    #[Route('/etudiant', name: 'app_etudiant')]
    public function index(EtudiantRepository $etudiantRepository , Request $request): Response
    {
        $result = $etudiantRepository->findAll();
        $etudiant =new Etudiant;
        $form = $this->createForm(EtudiantFormType::class, $etudiant);

        $form->handleRequest($request);
       
        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($etudiant);
            $entityManager->flush();

            return $this->redirectToRoute('app_etudiant');
          
        }
        return $this->render('etudiant/index.html.twig', [
            'list' => $result,
            'form' => $form->createView(),
        ]);
    }
    #[Route('/etudiant/delete/{id}', name: 'delet_etudiant')]

    public function delete($id): Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $etudiant = $entityManager->getRepository(Etudiant::class)->findOneBy(['id' => $id]);

        if (!$etudiant) {
            throw $this->createNotFoundException('etudiant not found');
        }

        $entityManager->remove($etudiant);
        $entityManager->flush();

        $this->addFlash('success', 'Le etudiant a été supprimé avec succès.');

        return $this->redirectToRoute('app_etudiant'); 
    }
    #[Route('/etudiant/modif/{id}', name: 'modif_etudiant')]
    public function modif($id , Request $request): Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $etudiant = $entityManager->getRepository(Etudiant::class)->findOneBy(['id' => $id]);
        $form = $this->createForm(EtudiantFormType::class, $etudiant);

        $form->handleRequest($request);
       
        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($etudiant);
            $entityManager->flush();

            return $this->redirectToRoute('app_etudiant');
        }
        return $this->render('etudiant/modif.html.twig', [
            'form' => $form->createView(),
        ]);
    }
}