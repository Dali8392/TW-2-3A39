<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AuthorController extends AbstractController
{ 
  public  $authors = array(
        array('id' => 1, 'picture' => '/images/Victor-Hugo.jpg','username' => 'Victor Hugo', 'email' =>
        'victor.hugo@gmail.com ', 'nb_books' => 10),
        array('id' => 2, 'picture' => '/images/william-shakespeare.jpg','username' => ' William Shakespeare', 'email' =>
        ' william.shakespeare@gmail.com', 'nb_books' => 200 ),
        array('id' => 3, 'picture' => '/images/Taha_Hussein.jpg','username' => 'Taha Hussein', 'email' =>
        'taha.hussein@gmail.com', 'nb_books' => 300),
        );
     
    #[Route('/author/{name}', name: 'app_author')]
    public function showAuthor($name): Response
    {
        return $this->render('author/index.html.twig', [
            'name' => $name,
        ]);
    }
    #[Route('/authors', name: 'tab')]
    public function showTab(): Response
    {
        
        return $this->render('author/index.html.twig', [
            'a' => $this->authors,
        ]);
    }
    #[Route('/detail/{id}', name: 'detail')]
    public function detail($id):Response{
  return $this->render('author/detail.html.twig', [
    'auther' => $this->authors[$id-1],
]);
    }
}